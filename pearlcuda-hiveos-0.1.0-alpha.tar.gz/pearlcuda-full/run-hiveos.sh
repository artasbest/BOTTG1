#!/usr/bin/env bash
set -euo pipefail
PREFIX="${PEARLCUDA_PREFIX:-/hive/miners/pearlcuda}"
source "$PREFIX/env.sh"
exec "$PREFIX/source/hiveos/h-run.sh" "$@"
