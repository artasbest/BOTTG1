#!/usr/bin/env bash
set -euo pipefail

CUSTOM_HOME="${CUSTOM_HOME:-/hive/miners/pearlcuda}"
source "$CUSTOM_HOME/env.sh"
# Direct installs use source/config.env; HiveOS UI variables take precedence.
if [[ -z "${CUSTOM_URL:-}" && -f "$CUSTOM_HOME/source/config.env" ]]; then source "$CUSTOM_HOME/source/config.env"; fi

POOL="${CUSTOM_URL:-${POOL:-}}"
WALLET="${CUSTOM_USER:-${WALLET:-}}"
WORKER="${CUSTOM_TEMPLATE:-${WORKER:-$(hostname)}}"
PASSWORD="${CUSTOM_PASS:-${PASSWORD:-x}}"
GPUS="${GPUS:-0}"
ARGS="${CUSTOM_USER_CONFIG:-${ARGS:-}}"

if [[ -z "$POOL" || -z "$WALLET" ]]; then
  echo "Set CUSTOM_URL/CUSTOM_USER or POOL/WALLET" >&2
  exit 2
fi

exec "$PEARLCUDA_PY" -m pearlcuda \
  --pool "$POOL" \
  --wallet "$WALLET" \
  --worker "$WORKER" \
  --password "$PASSWORD" \
  --gpus "$GPUS" \
  $ARGS
