#!/usr/bin/env bash
set -euo pipefail
STATS="/run/pearlcuda-stats.json"
if [[ -f "$STATS" ]]; then
  cat "$STATS"
else
  echo '{"total_hashrate":0,"accepted":0,"rejected":0,"gpus":[]}'
fi
