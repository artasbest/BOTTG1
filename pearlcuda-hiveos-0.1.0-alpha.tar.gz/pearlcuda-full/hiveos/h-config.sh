#!/usr/bin/env bash
set -euo pipefail

# Compatible with HiveOS custom-miner variables; also usable manually.
cat <<EOF
{"url":"${CUSTOM_URL:-}","user":"${CUSTOM_USER:-}","worker":"${CUSTOM_TEMPLATE:-}","pass":"${CUSTOM_PASS:-x}","gpus":"${GPUS:-0}","args":"${CUSTOM_USER_CONFIG:-}"}
EOF
