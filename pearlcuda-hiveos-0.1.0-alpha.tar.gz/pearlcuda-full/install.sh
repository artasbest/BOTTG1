#!/usr/bin/env bash
set -euo pipefail

PREFIX="${PEARLCUDA_PREFIX:-/hive/miners/pearlcuda}"
if [[ -z "${PYTHON:-}" ]]; then
  if command -v python3.12 >/dev/null 2>&1; then PYTHON=python3.12; else PYTHON=python3; fi
else
  PYTHON="$PYTHON"
fi
PEARL_REPO="${PEARL_REPO:-https://github.com/pearl-research-labs/pearl.git}"

mkdir -p "$PREFIX"
cp -a . "$PREFIX/source"

if ! command -v git >/dev/null 2>&1; then
  echo "git is required" >&2; exit 1
fi
if ! command -v "$PYTHON" >/dev/null 2>&1; then
  echo "Python 3.12+ is required (set PYTHON=/path/to/python3.12)" >&2; exit 1
fi
PYVER=$("$PYTHON" -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
if [[ "${PYVER%%.*}" -lt 3 || ( "${PYVER%%.*}" -eq 3 && "${PYVER##*.}" -lt 12 ) ]]; then
  echo "PearlCUDA requires Python 3.12+; detected $PYVER" >&2; exit 1
fi

if [[ ! -d "$PREFIX/pearl-src/.git" ]]; then
  git clone --recurse-submodules --depth 1 "$PEARL_REPO" "$PREFIX/pearl-src"
else
  git -C "$PREFIX/pearl-src" fetch --depth 1 origin
  git -C "$PREFIX/pearl-src" reset --hard origin/HEAD || true
  git -C "$PREFIX/pearl-src" submodule update --init --recursive || true
fi

"$PYTHON" -m venv --clear "$PREFIX/venv"
"$PREFIX/venv/bin/python" -m pip install --upgrade pip wheel setuptools
"$PREFIX/venv/bin/pip" install -r "$PREFIX/source/requirements.txt"

# Install the official Pearl workspace packages. This may compile CUDA/Rust components.
if command -v uv >/dev/null 2>&1; then
  UV=uv
else
  "$PREFIX/venv/bin/pip" install uv
  UV="$PREFIX/venv/bin/uv"
fi

cd "$PREFIX/pearl-src"
# Keep the official workspace and our runtime in the same venv; otherwise uv's
# project-local .venv would be invisible to h-run.sh.
UV_PROJECT_ENVIRONMENT="$PREFIX/venv" "$UV" sync --package pearl-gemm --package py-pearl-mining --no-editable
"$PREFIX/venv/bin/pip" install --no-deps -e "$PREFIX/source"

# Make local source importable and record runtime paths.
cat > "$PREFIX/env.sh" <<EOF
export PEARLCUDA_HOME="$PREFIX"
export PEARLCUDA_PY="$PREFIX/venv/bin/python"
export PYTHONPATH="$PREFIX/source/src:$PREFIX/pearl-src/miner/pearl-gemm/src:$PREFIX/pearl-src/py-pearl-mining/src:$PREFIX/pearl-src/miner/miner-base/src:\${PYTHONPATH:-}"
export TORCH_CUDA_ARCH_LIST="${TORCH_CUDA_ARCH_LIST:-8.6;8.9;9.0;12.0}"
EOF

chmod +x "$PREFIX/source/hiveos"/*.sh
ln -sf "$PREFIX/source/hiveos/h-run.sh" "$PREFIX/run-hiveos.sh"

echo "PearlCUDA installed in $PREFIX"
echo "Edit $PREFIX/source/config.env and run $PREFIX/run-hiveos.sh"
echo "For HiveOS, use the h-run.sh/h-stats.sh files under $PREFIX/source/hiveos/"
