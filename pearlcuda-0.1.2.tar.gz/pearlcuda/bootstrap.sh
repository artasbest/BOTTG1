#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PREFIX="$ROOT"

# HiveOS often has an older /usr/bin/python3. Do NOT accept it blindly.
PYTHON="${PYTHON:-}"
version_ok() {
  local p="$1"
  "$p" - <<'PY' >/dev/null 2>&1
import sys
raise SystemExit(0 if sys.version_info >= (3,11) else 1)
PY
}

if [[ -z "$PYTHON" ]]; then
  for p in python3.12 python3.11 /usr/bin/python3.12 /usr/bin/python3.11 python3; do
    if command -v "$p" >/dev/null 2>&1 && version_ok "$p"; then
      PYTHON="$(command -v "$p")"
      break
    fi
  done
fi

# Install Python 3.11 automatically on Debian/Ubuntu based HiveOS when possible.
if [[ -z "$PYTHON" ]]; then
  echo '[PearlCUDA] Python 3.11+ not found; attempting automatic install...'
  if [[ "$(id -u)" -eq 0 ]] && command -v apt-get >/dev/null 2>&1; then
    export DEBIAN_FRONTEND=noninteractive
    apt-get update -qq
    apt-get install -y -qq python3.11 python3.11-venv python3.11-distutils || true
    for p in /usr/bin/python3.11 python3.11; do
      if command -v "$p" >/dev/null 2>&1 && version_ok "$p"; then
        PYTHON="$(command -v "$p")"
        break
      fi
    done
  fi
fi

[[ -n "$PYTHON" ]] || { echo 'PearlCUDA: Python 3.11+ required. Install python3.11 and python3.11-venv.' >&2; exit 1; }
echo "[PearlCUDA] Using Python: $PYTHON ($($PYTHON --version 2>&1))"

command -v git >/dev/null 2>&1 || { echo 'PearlCUDA: git is required. Install it with: apt-get update && apt-get install -y git' >&2; exit 1; }

if [[ ! -d "$PREFIX/pearl-src/.git" ]]; then
  echo '[PearlCUDA] Cloning Pearl source...'
  git clone --recurse-submodules --depth 1 https://github.com/pearl-research-labs/pearl.git "$PREFIX/pearl-src"
fi

if [[ ! -x "$PREFIX/venv/bin/python" ]]; then
  echo '[PearlCUDA] Creating Python 3.11 virtual environment...'
  "$PYTHON" -m venv "$PREFIX/venv"
  "$PREFIX/venv/bin/python" -m pip install --upgrade pip wheel setuptools
  "$PREFIX/venv/bin/pip" install -r "$PREFIX/source/requirements.txt"
  "$PREFIX/venv/bin/pip" install uv
  cd "$PREFIX/pearl-src"
  UV_PROJECT_ENVIRONMENT="$PREFIX/venv" "$PREFIX/venv/bin/uv" sync --package pearl-gemm --package py-pearl-mining --no-editable
  "$PREFIX/venv/bin/pip" install --no-deps -e "$PREFIX/source"
fi

cat > "$PREFIX/env.sh" <<EOF2
export PEARLCUDA_HOME="$PREFIX"
export PEARLCUDA_PY="$PREFIX/venv/bin/python"
export PYTHONPATH="$PREFIX/source/src:$PREFIX/pearl-src/miner/pearl-gemm/src:$PREFIX/pearl-src/py-pearl-mining/src:$PREFIX/pearl-src/miner/miner-base/src:\${PYTHONPATH:-}"
export TORCH_CUDA_ARCH_LIST="8.6;8.9;9.0;12.0"
EOF2

echo '[PearlCUDA] Bootstrap complete.'
