#!/usr/bin/env bash

miner_ver() { echo "0.1.1"; }
miner_config_echo() {
  [[ -f "$CUSTOM_CONFIG_FILENAME" ]] && cat "$CUSTOM_CONFIG_FILENAME" || echo "PearlCUDA configuration is generated from Flight Sheet variables."
}
miner_config_gen() {
  cat > "$CUSTOM_CONFIG_FILENAME" <<EOF2
POOL=${CUSTOM_URL:-}
WALLET=${CUSTOM_USER:-}
WORKER=${CUSTOM_TEMPLATE:-$WORKER_NAME}
PASSWORD=${CUSTOM_PASS:-x}
GPUS=${CUSTOM_USER_CONFIG:-0}
EOF2
}
