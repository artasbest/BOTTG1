from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import threading
import time
from dataclasses import asdict

import numpy as np
from blake3 import blake3

from .backend import CudaDenseEngine
from .config import MiningConfig, parse_hex_config
from .noise import noise_factors
from .proof import build_plain_proof, roundtrip_plain_proof
from .stratum import Job, StratumClient


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="PearlCUDA dense PearlHash miner for NVIDIA SM86/SM89/SM90")
    p.add_argument("--pool", required=True)
    p.add_argument("--wallet", required=True)
    p.add_argument("--worker", default=os.uname().nodename if hasattr(os, "uname") else "pearlcuda")
    p.add_argument("--password", default="x")
    p.add_argument("--gpus", default="0")
    p.add_argument("--m", type=int, default=32768)
    p.add_argument("--n", type=int, default=32768)
    p.add_argument("--k", type=int, default=2048)
    p.add_argument("--rank", type=int, default=128)
    p.add_argument("--mining-config-hex")
    p.add_argument("--noise-workers", type=int, default=max(1, min(8, os.cpu_count() or 1)))
    p.add_argument("--stats-file", default="/run/pearlcuda-stats.json")
    p.add_argument("--no-proof-roundtrip", action="store_true")
    p.add_argument("--benchmark", action="store_true")
    p.add_argument("--benchmark-seconds", type=float, default=30)
    return p.parse_args()


def job_key(header: bytes, config_bytes: bytes) -> bytes:
    if len(header) != 76:
        raise ValueError("header must be exactly 76 bytes")
    return blake3(header + config_bytes).digest()


def derive_noise_seeds(jobkey: bytes, hash_b: bytes, hash_a: bytes) -> tuple[bytes, bytes]:
    # Current dense commitment derivation: b_seed = BLAKE3(job_key || hash_b),
    # a_seed = BLAKE3(b_seed || hash_a).
    b_seed = blake3(jobkey + hash_b).digest()
    a_seed = blake3(b_seed + hash_a).digest()
    return a_seed, b_seed


def jackpot_hash(words: np.ndarray, a_noise_seed: bytes) -> bytes:
    return blake3(words.astype("<u4", copy=False).tobytes(), key=a_noise_seed).digest()


def meets_target(jackpot: bytes, target: bytes) -> bool:
    # Pearl's jackpot is compared as a little-endian U256; Stratum target is
    # transported as a big-endian 32-byte threshold.
    return int.from_bytes(jackpot, "little") <= int.from_bytes(target, "big")


def write_stats(path: str, payload: dict) -> None:
    try:
        d = os.path.dirname(path)
        if d:
            os.makedirs(d, exist_ok=True)
        tmp = path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(payload, f, separators=(",", ":"))
        os.replace(tmp, path)
    except OSError:
        pass


class Worker(threading.Thread):
    def __init__(self, gpu: int, client: StratumClient, args: argparse.Namespace):
        super().__init__(name=f"gpu-{gpu}", daemon=True)
        self.gpu = gpu
        self.client = client
        self.args = args
        self.total_hash = 0
        self.samples = 0
        self.shares = 0
        self.errors = 0
        self.running = True
        self.last_job_id = None
        self.last_time = time.monotonic()
        self.rate = 0.0
        self._local_job = None
        self.engine = None

    def _new_engine(self, job: Job) -> tuple[CudaDenseEngine, MiningConfig]:
        raw = parse_hex_config(job.config_hex) if job.config_hex else parse_hex_config(self.args.mining_config_hex)
        cfg = MiningConfig(
            m=job.m or self.args.m,
            n=job.n or self.args.n,
            k=job.k or self.args.k,
            rank=job.rank or self.args.rank,
            raw_bytes=raw,
        )
        cfg.validate()
        return CudaDenseEngine(cfg, self.gpu), cfg

    def _mine_job(self, job: Job) -> None:
        if job.seed_derivation.lower() not in {"legacy", "seedderivation::legacy"}:
            raise RuntimeError(f"unsupported Pearl seed derivation {job.seed_derivation!r}; refusing to submit potentially invalid shares")
        if self.engine is None or self.last_job_id != job.job_id:
            self.engine, cfg = self._new_engine(job)
            self.cfg = cfg
            self.local_jobkey = job_key(job.header, cfg.to_bytes())
            try:
                name = __import__('torch').cuda.get_device_name(self.gpu)
            except Exception:
                name = 'unknown'
            print(f"[GPU{self.gpu}] {name} job={job.job_id} m={cfg.m} n={cfg.n} k={cfg.k} rank={cfg.rank}", flush=True)

        cfg = self.cfg
        e = self.engine
        while self.running and self.client.job is job:
            started = time.perf_counter()
            e.make_candidate()
            try:
                hash_a, hash_b = e.commitment_roots(self.local_jobkey)
                a_seed, b_seed = derive_noise_seeds(self.local_jobkey, hash_b, hash_a)
                eal, ebr, ar1, ar2, bl1, bl2 = noise_factors(
                    cfg.selected_rows,
                    cfg.selected_cols,
                    cfg.k,
                    cfg.rank,
                    a_seed,
                    b_seed,
                    workers=self.args.noise_workers,
                )
                e.prepare_noised_selects(eal, ebr, ar1, ar2, bl1, bl2)
                transcripts = e.jackpot_transcripts()
                elapsed = max(1e-9, time.perf_counter() - started)
                self.total_hash += cfg.work_units
                self.rate = self.total_hash / max(1e-9, time.monotonic() - self.last_time)
                self.samples += 1

                jackpot_size = cfg.k // cfg.rank
                winning_tile = None
                winning_hash = None
                for tile_id in range(transcripts.shape[0]):
                    transcript = transcripts[tile_id, :jackpot_size]
                    digest = jackpot_hash(transcript, a_seed)
                    if meets_target(digest, job.target):
                        winning_tile = tile_id
                        winning_hash = digest
                        break

                if winning_tile is None:
                    continue

                # Map logical tile back to the original dense matrices.
                row_tile = winning_tile // cfg.col_tiles
                col_tile = winning_tile % cfg.col_tiles
                row_start = row_tile * len(cfg.rows_pattern)
                col_start = col_tile * len(cfg.cols_pattern)
                proof_rows = [cfg.selected_rows[row_start + i] for i in range(len(cfg.rows_pattern))]
                proof_cols = [cfg.selected_cols[col_start + i] for i in range(len(cfg.cols_pattern))]

                # Copy only on a real winning tile; proof construction is intentionally
                # off the hot path because it hashes the complete committed matrices.
                a_cpu = e.a.cpu().numpy().astype(np.int8, copy=False)
                bt_cpu = e.bt.cpu().numpy().astype(np.int8, copy=False)
                proof_b64 = build_plain_proof(
                    a_cpu,
                    bt_cpu,
                    self.local_jobkey,
                    cfg.m,
                    cfg.n,
                    cfg.k,
                    cfg.rank,
                    proof_rows,
                    proof_cols,
                )
                if not self.args.no_proof_roundtrip:
                    roundtrip_plain_proof(proof_b64)

                # Keep the protocol submission minimal: plain_proof is authoritative;
                # hs and lpm_shape are optional telemetry.
                self.client.submit(job.job_id, proof_b64)
                self.shares += 1
                print(
                    f"[GPU{self.gpu}] SHARE candidate tile={winning_tile} hash={winning_hash.hex()} "
                    f"proof={len(proof_b64)}B elapsed={elapsed:.3f}s",
                    flush=True,
                )
                # Abandon this job immediately. The pool may have advanced after the submit.
                return
            except Exception as exc:
                self.errors += 1
                sys.stderr.write(f"[GPU{self.gpu}] mining error: {exc}\n")
                time.sleep(0.2)
                return

    def run(self) -> None:
        while self.running:
            job = self.client.job
            if job is None:
                time.sleep(0.1)
                continue
            try:
                self._mine_job(job)
            except Exception as exc:
                self.errors += 1
                sys.stderr.write(f"[GPU{self.gpu}] {exc}\n")
                time.sleep(1.0)



def main() -> int:
    args = parse_args()
    gpus = [int(x) for x in args.gpus.split(",") if x.strip()]
    client = StratumClient(args.pool, args.wallet, args.worker, args.password)
    client.connect()
    workers = [Worker(g, client, args) for g in gpus]
    for w in workers:
        w.start()

    try:
        while any(w.is_alive() for w in workers):
            time.sleep(5)
            if not client.connected:
                print(f"[Stratum] disconnected: {client.last_error}; reconnecting", flush=True)
                try:
                    client.reconnect(2.0)
                except Exception as exc:
                    client.last_error = str(exc)
                    time.sleep(2.0)
            hs = [w.rate / 1e12 for w in workers]
            payload = {
                "total_hash": int(sum(w.total_hash for w in workers)),
                "total_hashrate": float(sum(hs)),
                "accepted": client.accepted,
                "rejected": client.rejected,
                "gpus": [
                    {"gpu": w.gpu, "hashrate": w.rate / 1e12, "samples": w.samples, "errors": w.errors}
                    for w in workers
                ],
            }
            write_stats(args.stats_file, payload)
            print(f"[PearlCUDA] {payload['total_hashrate']:.3f} TH/s | accepted={client.accepted} rejected={client.rejected}", flush=True)
    except KeyboardInterrupt:
        pass
    finally:
        for w in workers:
            w.running = False
        client.close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
