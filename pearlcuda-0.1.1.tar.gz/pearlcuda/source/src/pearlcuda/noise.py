from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from typing import Iterable

import numpy as np
from blake3 import blake3

NOISE_RANGE = 128
UNIFORM_NOISE_RANGE = 64
ZERO_POINT_TRANSLATION = 32
RANGE_MASK = 127
LINES_PER_HASH = 8


def _seed_label(label: bytes) -> bytes:
    if len(label) > 32:
        raise ValueError("seed label must be <=32 bytes")
    return label.ljust(32, b"\0")


def get_random_hash(index: int, seed: bytes, key: bytes, prepend_index: int) -> bytes:
    """Exact byte layout used by Pearl's current dense-noise generator."""
    if len(seed) != 32 or len(key) != 32:
        raise ValueError("seed and key must be exactly 32 bytes")
    if prepend_index not in (0, 1):
        raise ValueError("prepend_index must be 0 or 1")
    msg = bytearray(64)
    msg[prepend_index * 4:prepend_index * 4 + 4] = (1 + index).to_bytes(4, "little", signed=False)
    msg[32:64] = seed
    return blake3(bytes(msg), key=key).digest()


def _uniform_one(row_idx: int, seed: bytes, key: bytes, rank: int) -> np.ndarray:
    out = np.empty(rank, dtype=np.int8)
    pos = 0
    block = 0
    while pos < rank:
        h = get_random_hash(block + (row_idx * rank) // 32, seed, key, 0)
        for b in h:
            if pos >= rank:
                break
            out[pos] = np.int8((b & RANGE_MASK) - ZERO_POINT_TRANSLATION)
            pos += 1
        block += 1
    return out


def uniform_noise_rows(indices: Iterable[int], seed: bytes, key: bytes, rank: int, workers: int = 0) -> np.ndarray:
    idxs = [int(x) for x in indices]
    if not idxs:
        return np.empty((0, rank), dtype=np.int8)
    fn = lambda x: _uniform_one(x, seed, key, rank)
    if workers <= 0:
        workers = min(8, len(idxs))
    if workers == 1:
        rows = [fn(x) for x in idxs]
    else:
        with ThreadPoolExecutor(max_workers=workers) as ex:
            rows = list(ex.map(fn, idxs))
    return np.stack(rows, axis=0).astype(np.int8, copy=False)


def _mul_hi_u32(a: int, b: int) -> int:
    return ((a * b) >> 32) & 0xFFFFFFFF


def permutation(k: int, rank: int, seed: bytes, key: bytes) -> tuple[np.ndarray, np.ndarray]:
    if rank <= 0 or (rank & (rank - 1)) != 0:
        raise ValueError("noise rank must be a power of two")
    if rank % 32 != 0:
        raise ValueError("noise rank must be divisible by 32")
    first = np.empty(k, dtype=np.int16)
    second = np.empty(k, dtype=np.int16)
    mask = rank - 1
    for base in range(0, k, LINES_PER_HASH):
        h = get_random_hash(base // LINES_PER_HASH, seed, key, 1)
        words = np.frombuffer(h, dtype="<u4")
        for j in range(min(LINES_PER_HASH, k - base)):
            r = int(words[j])
            a = r & mask
            b = a ^ (1 + _mul_hi_u32(mask, r))
            first[base + j] = a
            second[base + j] = b
    return first, second


def noise_factors(
    rows: list[int],
    cols: list[int],
    k: int,
    rank: int,
    a_noise_seed: bytes,
    b_noise_seed: bytes,
    workers: int = 0,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    # EAL/E_B_R are compact r-column factors. The sparse permutation vectors
    # expand them into the required k-column additive noise on GPU.
    seed_a = _seed_label(b"A_tensor")
    seed_b = _seed_label(b"B_tensor")
    eal = uniform_noise_rows(rows, seed_a, a_noise_seed, rank, workers=workers)
    ebr = uniform_noise_rows(cols, seed_b, b_noise_seed, rank, workers=workers)
    ar1, ar2 = permutation(k, rank, seed_a, a_noise_seed)
    bl1, bl2 = permutation(k, rank, seed_b, b_noise_seed)
    return eal, ebr, ar1, ar2, bl1, bl2
