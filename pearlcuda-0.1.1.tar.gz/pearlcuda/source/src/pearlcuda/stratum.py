from __future__ import annotations

import json
import socket
import ssl
import threading
import time
from dataclasses import dataclass
from urllib.parse import urlparse


@dataclass
class Job:
    job_id: str
    header: bytes
    target: bytes
    height: int | None = None
    config_hex: str | None = None
    m: int = 32768
    n: int = 32768
    k: int = 2048
    rank: int = 128
    seed_derivation: str = "legacy"


class StratumClient:
    def __init__(self, pool: str, wallet: str, worker: str, password: str = "x", subscribe: bool = True):
        p = urlparse(pool if "://" in pool else f"stratum://{pool}")
        self.host = p.hostname
        self.port = p.port
        self.tls = p.scheme in {"stratum+ssl", "stratum+tls", "ssl"}
        if not self.host or not self.port:
            raise ValueError(f"invalid pool URL: {pool}")
        self.wallet = wallet
        self.worker = worker or "pearlcuda"
        self.password = password
        self.subscribe = subscribe
        self.sock: socket.socket | ssl.SSLSocket | None = None
        self.file = None
        self._id = 1
        self._send_lock = threading.Lock()
        self._job_lock = threading.Lock()
        self._job: Job | None = None
        self._stop = threading.Event()
        self._reader: threading.Thread | None = None
        self.accepted = 0
        self.rejected = 0
        self.last_error = ""

    @property
    def job(self) -> Job | None:
        with self._job_lock:
            return self._job

    def _next_id(self) -> int:
        x = self._id
        self._id += 1
        return x


    @property
    def connected(self) -> bool:
        return self.file is not None and self._reader is not None and self._reader.is_alive()

    def connect(self) -> None:
        raw = socket.create_connection((self.host, self.port), timeout=15)
        raw.settimeout(None)
        if self.tls:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            self.sock = ctx.wrap_socket(raw, server_hostname=self.host)
        else:
            self.sock = raw
        self.file = self.sock.makefile("rwb", buffering=0)
        self._send("mining.subscribe", [], req_id=0)
        self._send("mining.authorize", [f"{self.wallet}.{self.worker}", self.password], req_id=1)
        self._reader = threading.Thread(target=self._reader_loop, name="stratum", daemon=True)
        self._reader.start()

    def reconnect(self, delay: float = 2.0) -> None:
        self._stop.set()
        with self._job_lock:
            self._job = None
        try:
            if self.file:
                self.file.close()
        except Exception:
            pass
        if self.sock:
            try:
                self.sock.close()
            except OSError:
                pass
        self.file = None
        self.sock = None
        time.sleep(delay)
        self._stop.clear()
        self.connect()

    def close(self) -> None:
        self._stop.set()
        try:
            if self.file:
                self.file.close()
        finally:
            self.file = None
            if self.sock:
                try:
                    self.sock.close()
                except OSError:
                    pass
            self.sock = None

    def _send(self, method: str, params, req_id: int | None = None) -> int:
        if req_id is None:
            req_id = self._next_id()
        else:
            self._id = max(self._id, int(req_id) + 1)
        msg = (json.dumps({"id": req_id, "method": method, "params": params}, separators=(",", ":")) + "\n").encode()
        with self._send_lock:
            if self.file is None:
                raise ConnectionError("stratum socket closed")
            self.file.write(msg)
            self.file.flush()
        return req_id

    def submit(self, job_id: str, proof_b64: str, hs: int | None = None, shape: dict | None = None) -> None:
        params = {"job_id": job_id, "plain_proof": proof_b64}
        if hs is not None:
            params["hs"] = int(max(0, hs))
        if shape is not None:
            params["lpm_shape"] = shape
        self._send("mining.submit", params)

    @staticmethod
    def _parse_job(params) -> Job | None:
        if isinstance(params, dict):
            job_id = str(params.get("job_id", params.get("id", "")))
            header_hex = str(params.get("header", ""))
            target_hex = str(params.get("target", ""))
            if not job_id or not header_hex or not target_hex:
                return None
            header = bytes.fromhex(header_hex)
            target = bytes.fromhex(target_hex)
            if len(header) != 76:
                raise ValueError(f"Pearl header must be 76 bytes, got {len(header)}")
            if len(target) != 32:
                raise ValueError(f"Pearl target must be 32 bytes, got {len(target)}")
            return Job(
                job_id=job_id,
                header=header,
                target=target,
                height=int(params["height"]) if params.get("height") is not None else None,
                config_hex=params.get("mining_config") or params.get("config"),
                m=int(params.get("m", 32768)),
                n=int(params.get("n", 32768)),
                k=int(params.get("k", 2048)),
                rank=int(params.get("rank", 128)),
                seed_derivation=str(params.get("seed_derivation", "legacy")),
            )
        return None

    def _reader_loop(self) -> None:
        while not self._stop.is_set() and self.file is not None:
            try:
                line = self.file.readline()
            except (OSError, ValueError) as exc:
                self.last_error = str(exc)
                break
            if not line:
                break
            try:
                msg = json.loads(line.decode())
            except Exception:
                continue
            if msg.get("method") == "mining.notify":
                try:
                    j = self._parse_job(msg.get("params"))
                    if j:
                        with self._job_lock:
                            self._job = j
                except Exception as exc:
                    self.last_error = f"notify: {exc}"
            elif "result" in msg and msg.get("id") not in (0, 1):
                if msg.get("result") is True:
                    self.accepted += 1
                elif msg.get("result") is False:
                    self.rejected += 1
            elif msg.get("error") is not None and msg.get("id") not in (0, 1):
                self.rejected += 1
                self.last_error = str(msg.get("error"))

