from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import numpy as np
import torch


_EXT = None


def load_reduce_extension() -> Any:
    global _EXT
    if _EXT is not None:
        return _EXT
    from torch.utils.cpp_extension import load
    src = Path(__file__).resolve().parents[2] / "cuda" / "tile_xor.cu"
    _EXT = load(
        name="pearlcuda_tile_xor",
        sources=[str(src)],
        extra_cuda_cflags=["-O3", "--use_fast_math"],
        verbose=bool(int(os.environ.get("PEARLCUDA_BUILD_VERBOSE", "0"))),
    )
    return _EXT


def _int8_mm(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    fn = getattr(torch, "_int_mm", None)
    if fn is not None:
        return fn(a, b)
    # Slow fallback: correctness only. On a production HiveOS rig _int_mm should exist.
    return torch.matmul(a.to(torch.int32), b.to(torch.int32))


class CudaDenseEngine:
    def __init__(self, cfg, device: int):
        self.cfg = cfg
        self.device = torch.device(f"cuda:{device}")
        torch.cuda.set_device(self.device)
        self.dev_id = device
        self.reduce = load_reduce_extension()
        self.a = torch.empty((cfg.m, cfg.k), dtype=torch.int8, device=self.device)
        self.bt = torch.empty((cfg.n, cfg.k), dtype=torch.int8, device=self.device)
        self.a_rows = torch.tensor(cfg.selected_rows, dtype=torch.int64, device=self.device)
        self.bt_rows = torch.tensor(cfg.selected_cols, dtype=torch.int64, device=self.device)
        self.a_sel = None
        self.bt_sel = None
        self.a0 = None
        self.a1 = None
        self.b0 = None
        self.b1 = None
        self.b0t = None
        self.b1t = None
        self.c = torch.empty(
            (len(cfg.selected_rows), len(cfg.selected_cols)),
            dtype=torch.int32,
            device=self.device,
        )

        try:
            from pearl_gemm import get_required_scratchpad_bytes, tensor_hash
        except Exception as exc:
            raise RuntimeError(
                "pearl_gemm is not installed. Run install.sh on HiveOS first."
            ) from exc
        self.tensor_hash = tensor_hash
        self.a_scratch = torch.empty(
            get_required_scratchpad_bytes(cfg.m * cfg.k), dtype=torch.uint8, device=self.device
        )
        self.b_scratch = torch.empty(
            get_required_scratchpad_bytes(cfg.n * cfg.k), dtype=torch.uint8, device=self.device
        )
        self.a_hash = torch.empty(32, dtype=torch.uint8, device=self.device)
        self.b_hash = torch.empty(32, dtype=torch.uint8, device=self.device)

    @staticmethod
    def _signed_decompose(x: torch.Tensor) -> tuple[torch.Tensor, torch.Tensor]:
        # x = low + 128 * high, with low in [-64,63]. This preserves signed
        # values outside int8 (the actual dense noised matrix reaches about +/-191).
        low = torch.remainder(x + 64, 128) - 64
        high = torch.div(x - low, 128, rounding_mode="floor")
        return low.to(torch.int8), high.to(torch.int8)

    def make_candidate(self) -> None:
        torch.randint(-64, 64, self.a.shape, dtype=torch.int8, device=self.device, out=self.a)
        torch.randint(-64, 64, self.bt.shape, dtype=torch.int8, device=self.device, out=self.bt)

    def commitment_roots(self, job_key: bytes) -> tuple[bytes, bytes]:
        key = torch.tensor(list(job_key), dtype=torch.uint8, device=self.device)
        self.tensor_hash(self.a, key, self.a_hash, self.a_scratch)
        self.tensor_hash(self.bt, key, self.b_hash, self.b_scratch)
        a = bytes(self.a_hash.cpu().tolist())
        b = bytes(self.b_hash.cpu().tolist())
        return a, b

    def prepare_noised_selects(self, eal: np.ndarray, ebr: np.ndarray, ar1: np.ndarray, ar2: np.ndarray, bl1: np.ndarray, bl2: np.ndarray) -> None:
        eal_t = torch.from_numpy(np.ascontiguousarray(eal)).to(self.device, non_blocking=True)
        ebr_t = torch.from_numpy(np.ascontiguousarray(ebr)).to(self.device, non_blocking=True)
        ar1_t = torch.from_numpy(np.ascontiguousarray(ar1.astype(np.int64))).to(self.device)
        ar2_t = torch.from_numpy(np.ascontiguousarray(ar2.astype(np.int64))).to(self.device)
        bl1_t = torch.from_numpy(np.ascontiguousarray(bl1.astype(np.int64))).to(self.device)
        bl2_t = torch.from_numpy(np.ascontiguousarray(bl2.astype(np.int64))).to(self.device)

        self.a_sel = self.a.index_select(0, self.a_rows).to(torch.int16)
        self.bt_sel = self.bt.index_select(0, self.bt_rows).to(torch.int16)
        noise_a = eal_t.index_select(1, ar1_t).to(torch.int16) - eal_t.index_select(1, ar2_t).to(torch.int16)
        noise_b = ebr_t.index_select(1, bl1_t).to(torch.int16) - ebr_t.index_select(1, bl2_t).to(torch.int16)
        self.a_sel.add_(noise_a)
        self.bt_sel.add_(noise_b)
        self.a0, self.a1 = self._signed_decompose(self.a_sel)
        self.b0, self.b1 = self._signed_decompose(self.bt_sel)
        # Transpose B components once per candidate, not once per 128-wide rank chunk.
        self.b0t = self.b0.t().contiguous()
        self.b1t = self.b1.t().contiguous()
        del eal_t, ebr_t, noise_a, noise_b, self.a_sel, self.bt_sel

    def jackpot_transcripts(self) -> np.ndarray:
        """Return one 16-word jackpot transcript per logical 2x64 tile.

        Shape: [number_of_tiles, k/rank]. Each rank chunk produces one XOR word.
        The host can then apply the exact BLAKE3 keyed jackpot hash to each tile.
        """
        total_tiles = self.cfg.row_tiles * self.cfg.col_tiles
        jackpot_size = self.cfg.k // self.cfg.rank
        transcripts = np.empty((total_tiles, jackpot_size), dtype=np.uint32)

        for tid, start in enumerate(range(0, self.cfg.k, self.cfg.rank)):
            end = start + self.cfg.rank
            a0 = self.a0[:, start:end].contiguous()
            a1 = self.a1[:, start:end].contiguous()
            # x = low + 128*high. Expand (A0+128A1)(B0+128B1) exactly.
            b0 = self.b0t[start:end]
            b1 = self.b1t[start:end]
            c = _int8_mm(a0, b0)
            t = _int8_mm(a0, b1)
            c.add_(t, alpha=128)
            del t
            t = _int8_mm(a1, b0)
            c.add_(t, alpha=128)
            del t
            t = _int8_mm(a1, b1)
            c.add_(t, alpha=16384)
            del t

            part = self.reduce.tile_xor(c, 2, 64)
            transcripts[:, tid] = part.cpu().numpy().astype(np.uint32, copy=False)
            del a0, a1, c, part

        return transcripts
