from __future__ import annotations

import base64
from dataclasses import dataclass

import numpy as np

try:
    from pearl_mining import MerkleTree, MatrixMerkleProof, PlainProof
except Exception as exc:  # pragma: no cover
    MerkleTree = MatrixMerkleProof = PlainProof = None
    _IMPORT_ERROR = exc


def _pad_to_chunk_boundary(data: bytes, chunk: int = 1024) -> bytes:
    rem = len(data) % chunk
    if rem == 0:
        return data
    return data + bytes(chunk - rem)


class MatrixMerkleTreeCompat:
    def __init__(self, tensor: np.ndarray, key: bytes):
        if MerkleTree is None:
            raise RuntimeError(f"pearl_mining import failed: {_IMPORT_ERROR}")
        raw = _pad_to_chunk_boundary(np.ascontiguousarray(tensor).tobytes())
        self.tree = MerkleTree(data=raw, key=key)
        self.shape = tuple(int(x) for x in tensor.shape)

    def proof_for_rows(self, rows: list[int]):
        indices = self.tree.compute_leaf_indices_from_rows(rows, self.shape)
        return self.tree.get_multileaf_proof(indices)


def build_plain_proof(
    a: np.ndarray,
    bt: np.ndarray,
    job_key: bytes,
    m: int,
    n: int,
    k: int,
    rank: int,
    a_rows: list[int],
    bt_rows: list[int],
) -> str:
    if PlainProof is None:
        raise RuntimeError(f"pearl_mining import failed: {_IMPORT_ERROR}")
    a_tree = MatrixMerkleTreeCompat(a, job_key)
    b_tree = MatrixMerkleTreeCompat(bt, job_key)
    a_mp = MatrixMerkleProof(proof=a_tree.proof_for_rows(a_rows), row_indices=a_rows)
    b_mp = MatrixMerkleProof(proof=b_tree.proof_for_rows(bt_rows), row_indices=bt_rows)
    proof = PlainProof(
        m=m,
        n=n,
        k=k,
        noise_rank=rank,
        a_merkle_proof=a_mp,
        bt_merkle_proof=b_mp,
        moe=None,
    )
    return proof.to_base64()


def roundtrip_plain_proof(encoded: str) -> None:
    if PlainProof is None:
        raise RuntimeError(f"pearl_mining import failed: {_IMPORT_ERROR}")
    raw = base64.b64decode(encoded, validate=True)
    PlainProof.deserialize_compat(raw)
