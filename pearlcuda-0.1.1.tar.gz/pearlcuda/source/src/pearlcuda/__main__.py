from .miner import main
raise SystemExit(main())
