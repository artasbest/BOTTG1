from __future__ import annotations

from dataclasses import dataclass

DEFAULT_ROWS = [0, 8]
DEFAULT_COLS = list(sum(([x, x + 1] for x in range(0, 256, 8)), []))


def pattern_bytes_default(rows: list[int], cols: list[int]) -> bytes:
    if rows != DEFAULT_ROWS:
        raise ValueError("Only current dense Ada row pattern [0,8] is supported in this build")
    if cols != DEFAULT_COLS:
        raise ValueError("Only current dense Ada column pattern is supported in this build")
    # Canonical PeriodicPattern encoding for [0,8] in a 16-wide period and
    # [0,1,8,9,...,248,249] in a 256-wide period.
    return bytes([7, 1, 0, 0, 0, 0, 0, 1, 3, 31, 0, 0])


@dataclass(frozen=True)
class MiningConfig:
    m: int = 32768
    n: int = 32768
    k: int = 2048
    rank: int = 128
    mma_type: int = 0
    rows_pattern: tuple[int, ...] = tuple(DEFAULT_ROWS)
    cols_pattern: tuple[int, ...] = tuple(DEFAULT_COLS)
    raw_bytes: bytes | None = None

    def to_bytes(self) -> bytes:
        if self.raw_bytes is not None:
            if len(self.raw_bytes) != 52:
                raise ValueError("mining config must be 52 bytes")
            return self.raw_bytes

        # Prefer the consensus library's own serializer. This avoids guessing the
        # compact PeriodicPattern wire encoding and guarantees job_key compatibility.
        try:
            from pearl_mining import MiningConfiguration as PMMiningConfiguration
            from pearl_mining import MMAType as PMMMAType
            from pearl_mining import PeriodicPattern as PMPeriodicPattern
            rows = PMPeriodicPattern.from_list(list(self.rows_pattern))
            cols = PMPeriodicPattern.from_list(list(self.cols_pattern))
            cfg = PMMiningConfiguration(
                common_dim=self.k,
                rank=self.rank,
                mma_type=PMMMAType.Int7xInt7ToInt32,
                rows_pattern=rows,
                cols_pattern=cols,
                moe=None,
            )
            raw = cfg.to_bytes()
            if len(raw) != 52:
                raise ValueError(f"official MiningConfiguration serializer returned {len(raw)} bytes")
            return bytes(raw)
        except Exception as exc:
            if self.m != 32768 or self.n != 32768 or self.k != 2048 or self.rank != 128 or self.mma_type != 0:
                raise RuntimeError("official pearl_mining serializer unavailable for non-default configuration") from exc
            # Conservative fallback for environments where the official Python API
            # does not expose the serializer. The installer always installs it.
            return (
                (self.k).to_bytes(4, "little")
                + (self.rank).to_bytes(2, "little")
                + (self.mma_type).to_bytes(2, "little")
                + pattern_bytes_default(list(self.rows_pattern), list(self.cols_pattern))
                + bytes(32)
            )

    @property
    def row_period(self) -> int:
        return 16

    @property
    def col_period(self) -> int:
        return 256

    def validate(self) -> None:
        if self.m % self.row_period or self.n % self.col_period:
            raise ValueError("m/n must be divisible by the current periodic pattern")
        if len(self.rows_pattern) != 2 or len(self.cols_pattern) != 64:
            raise ValueError("current optimized CUDA reduction expects 2x64 logical tiles")
        if self.rank & (self.rank - 1) or self.rank % 32:
            raise ValueError("rank must be a power of two and divisible by 32")
        if self.k % self.rank:
            raise ValueError("k must be divisible by rank")

    @property
    def selected_rows(self) -> list[int]:
        return [off + x for off in range(0, self.m, self.row_period) for x in self.rows_pattern]

    @property
    def selected_cols(self) -> list[int]:
        return [off + x for off in range(0, self.n, self.col_period) for x in self.cols_pattern]

    @property
    def row_tiles(self) -> int:
        return self.m // self.row_period

    @property
    def col_tiles(self) -> int:
        return self.n // self.col_period

    @property
    def work_units(self) -> int:
        # Logical multiply-adds actually performed by the selected row/column pattern.
        return len(self.selected_rows) * len(self.selected_cols) * self.k


def parse_hex_config(s: str | None) -> bytes | None:
    if not s:
        return None
    b = bytes.fromhex(s)
    if len(b) != 52:
        raise ValueError("--mining-config-hex must contain exactly 52 bytes / 104 hex chars")
    return b
