#!/usr/bin/env bash
set -euo pipefail
PREFIX="${PEARLCUDA_HOME:-/hive/miners/pearlcuda}"
source "$PREFIX/env.sh"

echo '=== NVIDIA ==='
nvidia-smi || true
echo '=== Python ==='
"$PEARLCUDA_PY" -V
"$PEARLCUDA_PY" - <<'PY'
import torch
print('torch:', torch.__version__)
print('torch.cuda:', torch.version.cuda)
print('cuda_available:', torch.cuda.is_available())
if torch.cuda.is_available():
    for i in range(torch.cuda.device_count()):
        print(i, torch.cuda.get_device_name(i), torch.cuda.get_device_capability(i))
for mod in ('pearl_mining', 'pearl_gemm', 'pearlcuda'):
    try:
        m=__import__(mod)
        print(mod, 'OK', getattr(m, '__file__', 'builtin'))
    except Exception as e:
        print(mod, 'ERROR', repr(e))
PY
