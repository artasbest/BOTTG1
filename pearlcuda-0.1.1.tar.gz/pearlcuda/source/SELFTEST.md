# Self-test checklist

Run on a CUDA-enabled HiveOS rig after installation:

```bash
source /hive/miners/pearlcuda/env.sh
$PEARLCUDA_PY - <<'PY'
from pearlcuda.config import MiningConfig
from pearlcuda.miner import job_key, derive_noise_seeds
from blake3 import blake3
cfg = MiningConfig(); cfg.validate()
assert len(cfg.to_bytes()) == 52
h = bytes(76)
k = job_key(h, cfg.to_bytes())
a,b = derive_noise_seeds(k, bytes(32), bytes(32))
print('config', cfg.to_bytes().hex())
print('job_key', k.hex())
print('seeds', a.hex(), b.hex())
PY
```

Then run the miner against a test pool or a private stratum endpoint. Do **not** treat a displayed rate alone as proof of protocol compatibility.
