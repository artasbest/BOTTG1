#include <torch/extension.h>
#include <ATen/cuda/CUDAContext.h>
#include <cuda.h>
#include <cuda_runtime.h>
#include <cstdint>

__global__ void tile_xor_kernel(const int32_t* __restrict__ c,
                                uint32_t* __restrict__ out,
                                int rows, int cols,
                                int tile_rows, int tile_cols) {
    const int tile_x_count = cols / tile_cols;
    const int tile_id = blockIdx.x;
    const int tr = tile_id / tile_x_count;
    const int tc = tile_id % tile_x_count;
    const int lane = threadIdx.x;

    uint32_t v = 0;
    if (lane < 64) {
        const int row = tr * tile_rows;
        const int col = tc * tile_cols + lane;
        if (row < rows && col < cols) v = static_cast<uint32_t>(c[row * cols + col]);
    } else if (lane < 128) {
        const int row = tr * tile_rows + 1;
        const int col = tc * tile_cols + (lane - 64);
        if (row < rows && col < cols) v = static_cast<uint32_t>(c[row * cols + col]);
    }

    for (int mask = 16; mask > 0; mask >>= 1) v ^= __shfl_down_sync(0xffffffff, v, mask);

    __shared__ uint32_t warp_xor[2];
    if ((lane & 31) == 0) warp_xor[lane >> 5] = v;
    __syncthreads();
    if (lane < 32) {
        uint32_t x = warp_xor[0] ^ warp_xor[1];
        for (int mask = 16; mask > 0; mask >>= 1) x ^= __shfl_down_sync(0xffffffff, x, mask);
        if (lane == 0) out[tile_id] = x;
    }
}

torch::Tensor tile_xor(torch::Tensor c, int64_t tile_rows, int64_t tile_cols) {
    TORCH_CHECK(c.is_cuda(), "c must be CUDA");
    TORCH_CHECK(c.scalar_type() == torch::kInt32, "c must be int32");
    TORCH_CHECK(c.dim() == 2, "c must be 2-D");
    TORCH_CHECK(tile_rows == 2 && tile_cols == 64, "this optimized kernel is fixed at 2x64");
    const auto rows = static_cast<int>(c.size(0));
    const auto cols = static_cast<int>(c.size(1));
    TORCH_CHECK(rows % 2 == 0 && cols % 64 == 0, "C shape must be divisible by 2x64");
    const int tiles = (rows / 2) * (cols / 64);
    auto out = torch::empty({tiles}, torch::TensorOptions().dtype(torch::kUInt32).device(c.device()));
    auto stream = at::cuda::getDefaultCUDAStream(c.device().index());
    tile_xor_kernel<<<tiles, 128, 0, stream.stream()>>>(
        c.data_ptr<int32_t>(), out.data_ptr<uint32_t>(), rows, cols, 2, 64);
    C10_CUDA_KERNEL_LAUNCH_CHECK();
    return out;
}

PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("tile_xor", &tile_xor, "Pearl 2x64 tile XOR reduction (CUDA)");
}
