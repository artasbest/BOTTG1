#!/usr/bin/env bash
set -euo pipefail
source "${PEARLCUDA_HOME:-/hive/miners/pearlcuda}/env.sh"
exec "$PEARLCUDA_PY" -m pearlcuda --help
