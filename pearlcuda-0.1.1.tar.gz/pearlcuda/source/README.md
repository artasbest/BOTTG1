# PearlCUDA HiveOS — 0.1.0-alpha

CUDA dense PearlHash miner alpha aimed at NVIDIA SM86/SM89/SM90, with the Ada path tuned around the current dense 32768×32768×2048 / rank-128 configuration.

## Current state

This build has the live Stratum/proof path enabled for the dense configuration, but it is still an alpha performance build. It only enables the current 2x64 logical tile pattern and should be validated against a real pool before treating its displayed rate as a benchmark win over an established miner.

The miner will not submit a proof until it has successfully round-tripped the `PlainProof` bincode/base64 representation through the official `pearl_mining` Python bindings.

## HiveOS install

1. Copy/extract this directory to the rig.
2. Run `./install.sh` (the official Pearl source is cloned with submodules and its `pearl-gemm` / `py-pearl-mining` packages are built in the local venv).
3. Set pool, wallet, worker and GPU in `config.env` or use HiveOS custom-miner variables.
4. Run `./run-hiveos.sh`.

First installation requires a working NVIDIA driver/CUDA toolchain and internet access because the official Pearl workspace is built on the rig. This development environment does not contain `nvcc`, so the CUDA extension was syntax-reviewed but not device-compiled here.

## Why this exists

The design deliberately avoids a fake standalone GEMM benchmark. It uses the current dense Pearl seed/key structure, selected row/column periodic patterns, wide integer noised values decomposed into four INT8 Tensor-Core GEMMs, and a CUDA tile XOR reducer.

The current implementation stores all 16 jackpot words for every logical 2x64 tile, applies keyed BLAKE3 to each transcript, maps the winning tile back to original matrix rows/columns, builds a `PlainProof`, round-trips it through the official binding, and then submits it.

## What is deliberately not promised

The package is designed to be benchmarkable against an established miner, but this environment cannot compile or benchmark CUDA (`nvcc` is not present and no RTX is attached). Therefore no honest claim of beating SRBMiner is made until the same pool/job is run on the target rig.

The hot path is designed around persistent GPU allocations, official Pearl Merkle-root hashing, GPU-side INT8 GEMM decomposition for the wider noised values, a custom 2x64 XOR reducer, and host-side jackpot BLAKE3/proof construction. The next optimization target after a correctness run is fusing the four INT8 GEMMs and tile reduction into one CUDA graph/kernel schedule; that is where a measured win over an optimized miner would have to come from.
