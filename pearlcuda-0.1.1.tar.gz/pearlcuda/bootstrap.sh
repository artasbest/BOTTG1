#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
PREFIX="$ROOT"
PYTHON="${PYTHON:-}"
if [[ -z "$PYTHON" ]]; then
  for p in python3.12 python3.11 python3; do command -v "$p" >/dev/null 2>&1 && PYTHON="$p" && break; done
fi
[[ -n "$PYTHON" ]] || { echo 'No Python 3 found' >&2; exit 1; }
command -v git >/dev/null 2>&1 || { echo 'git is required' >&2; exit 1; }
"$PYTHON" - <<'PY'
import sys
if sys.version_info < (3,11): raise SystemExit('Python 3.11+ required')
PY
if [[ ! -d "$PREFIX/pearl-src/.git" ]]; then
  git clone --recurse-submodules --depth 1 https://github.com/pearl-research-labs/pearl.git "$PREFIX/pearl-src"
fi
if [[ ! -x "$PREFIX/venv/bin/python" ]]; then
  "$PYTHON" -m venv "$PREFIX/venv"
  "$PREFIX/venv/bin/python" -m pip install --upgrade pip wheel setuptools
  "$PREFIX/venv/bin/pip" install -r "$PREFIX/source/requirements.txt"
  "$PREFIX/venv/bin/pip" install uv
  cd "$PREFIX/pearl-src"
  UV_PROJECT_ENVIRONMENT="$PREFIX/venv" "$PREFIX/venv/bin/uv" sync --package pearl-gemm --package py-pearl-mining --no-editable
  "$PREFIX/venv/bin/pip" install --no-deps -e "$PREFIX/source"
fi
cat > "$PREFIX/env.sh" <<EOF2
export PEARLCUDA_HOME="$PREFIX"
export PEARLCUDA_PY="$PREFIX/venv/bin/python"
export PYTHONPATH="$PREFIX/source/src:$PREFIX/pearl-src/miner/pearl-gemm/src:$PREFIX/pearl-src/py-pearl-mining/src:$PREFIX/pearl-src/miner/miner-base/src:\${PYTHONPATH:-}"
export TORCH_CUDA_ARCH_LIST="8.6;8.9;9.0;12.0"
EOF2
