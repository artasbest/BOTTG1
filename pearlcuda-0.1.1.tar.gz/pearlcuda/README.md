# PearlCUDA 0.1.1

HiveOS custom-miner package for the PearlHash CUDA prototype.

Important: this package is protocol-focused and performance-oriented, but it has not been benchmarked on a physical RTX 4070 Super in this environment. Do not treat its hashrate as proven superior to SRBMiner until live A/B testing is done.

HiveOS installs it as `/hive/miners/custom/pearlcuda/`. The first start builds the official Pearl CUDA/Python dependencies locally.
