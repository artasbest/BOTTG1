#!/usr/bin/env bash
set -euo pipefail
ROOT="/hive/miners/custom/pearlcuda"
cd "$ROOT"
if [[ ! -x "$ROOT/venv/bin/python" ]]; then
  echo '[PearlCUDA] First run: building runtime and CUDA dependencies...'
  "$ROOT/bootstrap.sh"
fi
source "$ROOT/env.sh"
POOL="${CUSTOM_URL:-}"
WALLET="${CUSTOM_USER:-}"
WORKER="${WORKER_NAME:-pearlcuda}"
PASS="${CUSTOM_PASS:-x}"
GPUS="${PEARLCUDA_GPUS:-${GPU_IDs:-0}}"
ARGS="${CUSTOM_USER_CONFIG:-}"
[[ -n "$POOL" && -n "$WALLET" ]] || { echo 'PearlCUDA: configure pool and wallet in Flight Sheet' >&2; exit 2; }
exec "$PEARLCUDA_PY" -m pearlcuda --pool "$POOL" --wallet "$WALLET" --worker "$WORKER" --password "$PASS" --gpus "$GPUS" $ARGS
