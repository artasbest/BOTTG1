#!/usr/bin/env bash
STATS=/run/pearlcuda-stats.json
khs=0
stats='{"hs":[0],"hs_units":"hs","ar":[0,0],"algo":"pearlhash","ver":"0.1.1"}'
if [[ -s "$STATS" ]]; then
  total=$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(int(d.get("total_hashrate",0)))' "$STATS" 2>/dev/null || echo 0)
  acc=$(python3 -c 'import json,sys; print(int(json.load(open(sys.argv[1])).get("accepted",0)))' "$STATS" 2>/dev/null || echo 0)
  rej=$(python3 -c 'import json,sys; print(int(json.load(open(sys.argv[1])).get("rejected",0)))' "$STATS" 2>/dev/null || echo 0)
  khs=$total
  stats=$(printf '{"hs":[%s],"hs_units":"hs","ar":[%s,%s],"algo":"pearlhash","ver":"0.1.1"}' "$total" "$acc" "$rej")
fi
